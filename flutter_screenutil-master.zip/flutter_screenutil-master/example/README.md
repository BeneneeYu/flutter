# example

flutter_screenutil的使用示例

![效果](../demo_zh.png)
![effect](../demo_en.png)

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).
